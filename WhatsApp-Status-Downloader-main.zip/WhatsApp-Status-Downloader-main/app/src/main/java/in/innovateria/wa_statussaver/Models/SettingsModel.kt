package `in`.innovateria.wa_statussaver.Models

data class SettingsModel(
    val title:String,
    val desc:String
)